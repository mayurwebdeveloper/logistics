<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="h3 mb-0">Dashboard</h1>
            <p class="text-muted">Welcome back, <?php echo e(Auth::guard('admin')->user()->name); ?>!</p>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card stats-card card-stats border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <h5 class="card-title text-uppercase text-muted mb-0">Total Consignments</h5>
                            <span class="h2 font-weight-bold mb-0"><?php echo e($stats['total_consignments']); ?></span>
                        </div>
                        <div class="col-auto">
                            <div class="icon icon-shape bg-primary text-white rounded-circle shadow">
                                <i class="fas fa-box fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card stats-card card-stats success border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <h5 class="card-title text-uppercase text-muted mb-0">Active Trucks</h5>
                            <span class="h2 font-weight-bold mb-0"><?php echo e($stats['total_trucks']); ?></span>
                        </div>
                        <div class="col-auto">
                            <div class="icon icon-shape bg-success text-white rounded-circle shadow">
                                <i class="fas fa-truck fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card stats-card card-stats warning border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <h5 class="card-title text-uppercase text-muted mb-0">Pending Deliveries</h5>
                            <span class="h2 font-weight-bold mb-0"><?php echo e($stats['pending_consignments']); ?></span>
                        </div>
                        <div class="col-auto">
                            <div class="icon icon-shape bg-warning text-white rounded-circle shadow">
                                <i class="fas fa-clock fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card stats-card card-stats danger border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <h5 class="card-title text-uppercase text-muted mb-0">Total Invoices</h5>
                            <span class="h2 font-weight-bold mb-0"><?php echo e($stats['total_invoices']); ?></span>
                        </div>
                        <div class="col-auto">
                            <div class="icon icon-shape bg-danger text-white rounded-circle shadow">
                                <i class="fas fa-file-invoice fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Status Overview -->
    <div class="row mb-4">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-chart-pie me-2"></i>
                        Consignment Status Overview
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-3">
                            <div class="border-end">
                                <h4 class="text-warning"><?php echo e($stats['pending_consignments']); ?></h4>
                                <small class="text-muted">Pending</small>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="border-end">
                                <h4 class="text-info"><?php echo e($stats['in_transit_consignments']); ?></h4>
                                <small class="text-muted">In Transit</small>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="border-end">
                                <h4 class="text-success"><?php echo e($stats['delivered_consignments']); ?></h4>
                                <small class="text-muted">Delivered</small>
                            </div>
                        </div>
                        <div class="col-3">
                            <h4 class="text-primary"><?php echo e($stats['total_consignments']); ?></h4>
                            <small class="text-muted">Total</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-users me-2"></i>
                        Quick Stats
                    </h5>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span>Consignors</span>
                        <span class="badge bg-primary rounded-pill"><?php echo e($stats['total_consignors']); ?></span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <span>Consignees</span>
                        <span class="badge bg-success rounded-pill"><?php echo e($stats['total_consignees']); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Consignments -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-history me-2"></i>
                        Recent Consignments
                    </h5>
                    <a href="<?php echo e(route('admin.consignments.index')); ?>" class="btn btn-sm btn-outline-primary">
                        View All
                    </a>
                </div>
                <div class="card-body p-0">
                    <?php if($recent_consignments->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Consignment #</th>
                                        <th>Date</th>
                                        <th>From</th>
                                        <th>To</th>
                                        <th>Truck</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $recent_consignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo e($consignment->consignment_number); ?></strong>
                                            </td>
                                            <td><?php echo e($consignment->consignment_date->format('M d, Y')); ?></td>
                                            <td><?php echo e($consignment->consignor->name ?? 'N/A'); ?></td>
                                            <td><?php echo e($consignment->consignee->name ?? 'N/A'); ?></td>
                                            <td><?php echo e($consignment->truck->truck_number ?? 'N/A'); ?></td>
                                            <td>
                                                <?php switch($consignment->status):
                                                    case ('pending'): ?>
                                                        <span class="badge bg-warning">Pending</span>
                                                        <?php break; ?>
                                                    <?php case ('in_transit'): ?>
                                                        <span class="badge bg-info">In Transit</span>
                                                        <?php break; ?>
                                                    <?php case ('delivered'): ?>
                                                        <span class="badge bg-success">Delivered</span>
                                                        <?php break; ?>
                                                    <?php case ('cancelled'): ?>
                                                        <span class="badge bg-danger">Cancelled</span>
                                                        <?php break; ?>
                                                    <?php default: ?>
                                                        <span class="badge bg-secondary">Unknown</span>
                                                <?php endswitch; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('admin.consignments.show', $consignment)); ?>" 
                                                   class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-box fa-3x text-muted mb-3"></i>
                            <p class="text-muted">No consignments found. <a href="<?php echo e(route('admin.consignments.create')); ?>">Create your first consignment</a></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-bolt me-2"></i>
                        Quick Actions
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <a href="<?php echo e(route('admin.consignments.create')); ?>" class="btn btn-primary w-100">
                                <i class="fas fa-plus me-2"></i>
                                New Consignment
                            </a>
                        </div>
                        <div class="col-md-3 mb-3">
                            <a href="<?php echo e(route('admin.trucks.create')); ?>" class="btn btn-success w-100">
                                <i class="fas fa-truck me-2"></i>
                                Add Truck
                            </a>
                        </div>
                        <div class="col-md-3 mb-3">
                            <a href="<?php echo e(route('admin.consignors.create')); ?>" class="btn btn-info w-100">
                                <i class="fas fa-user-tie me-2"></i>
                                Add Consignor
                            </a>
                        </div>
                        <div class="col-md-3 mb-3">
                            <a href="<?php echo e(route('admin.consignees.create')); ?>" class="btn btn-warning w-100">
                                <i class="fas fa-users me-2"></i>
                                Add Consignee
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>
    .icon-shape {
        width: 48px;
        height: 48px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\logistics\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>