

<?php $__env->startSection('title', 'View Consignor'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col-md-6">
            <h1 class="h3 mb-0">View Consignor</h1>
            <p class="text-muted">Consignor details and information</p>
        </div>
        <div class="col-md-6 text-end">
            <a href="<?php echo e(route('admin.consignors.index')); ?>" class="btn btn-outline-secondary me-2">
                <i class="fas fa-arrow-left me-2"></i>
                Back to Consignors
            </a>
            <a href="<?php echo e(route('admin.consignors.edit', $consignor)); ?>" class="btn btn-warning me-2">
                <i class="fas fa-edit me-2"></i>
                Edit
            </a>
            <form method="POST" action="<?php echo e(route('admin.consignors.destroy', $consignor)); ?>" 
                  class="d-inline"
                  onsubmit="return confirm('Are you sure you want to delete this consignor?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">
                    <i class="fas fa-trash me-2"></i>
                    Delete
                </button>
            </form>
        </div>
    </div>

    <!-- Consignor Details -->
    <div class="row">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-user-tie me-2"></i>
                        Consignor Information
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold text-muted">Name</label>
                            <p class="form-control-plaintext"><?php echo e($consignor->name); ?></p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold text-muted">GST Number</label>
                            <p class="form-control-plaintext"><?php echo e($consignor->gst_no ?? 'N/A'); ?></p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold text-muted">Contact Person</label>
                            <p class="form-control-plaintext"><?php echo e($consignor->contact_person ?? 'N/A'); ?></p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold text-muted">Phone</label>
                            <p class="form-control-plaintext">
                                <?php if($consignor->phone): ?>
                                    <a href="tel:<?php echo e($consignor->phone); ?>" class="text-decoration-none">
                                        <?php echo e($consignor->phone); ?>

                                    </a>
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold text-muted">Email</label>
                            <p class="form-control-plaintext">
                                <?php if($consignor->email): ?>
                                    <a href="mailto:<?php echo e($consignor->email); ?>" class="text-decoration-none">
                                        <?php echo e($consignor->email); ?>

                                    </a>
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </p>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold text-muted">Status</label>
                            <p class="form-control-plaintext">
                                <?php if($consignor->is_active): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Inactive</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        
                        <div class="col-12 mb-3">
                            <label class="form-label fw-bold text-muted">Address</label>
                            <p class="form-control-plaintext"><?php echo e($consignor->address); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <!-- Quick Stats -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white">
                    <h6 class="card-title mb-0">
                        <i class="fas fa-chart-bar me-2"></i>
                        Quick Stats
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-6">
                            <div class="border-end">
                                <h4 class="text-primary mb-1"><?php echo e($consignor->consignments->count()); ?></h4>
                                <small class="text-muted">Total Consignments</small>
                            </div>
                        </div>
                        <div class="col-6">
                            <h4 class="text-success mb-1">
                                <?php echo e($consignor->consignments->where('status', 'delivered')->count()); ?>

                            </h4>
                            <small class="text-muted">Delivered</small>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Additional Info -->
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h6 class="card-title mb-0">
                        <i class="fas fa-info-circle me-2"></i>
                        Additional Information
                    </h6>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold text-muted">Created</label>
                        <p class="form-control-plaintext"><?php echo e($consignor->created_at->format('M d, Y \a\t h:i A')); ?></p>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold text-muted">Last Updated</label>
                        <p class="form-control-plaintext"><?php echo e($consignor->updated_at->format('M d, Y \a\t h:i A')); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Consignments -->
    <?php if($consignor->consignments->count() > 0): ?>
    <div class="row mt-4">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-box me-2"></i>
                        Recent Consignments
                    </h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Consignment #</th>
                                    <th>Date</th>
                                    <th>To</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $consignor->consignments->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo e($consignment->consignment_number); ?></strong>
                                        </td>
                                        <td><?php echo e($consignment->consignment_date->format('M d, Y')); ?></td>
                                        <td>
                                            <div>
                                                <strong><?php echo e($consignment->consignee->name ?? 'N/A'); ?></strong>
                                                <br>
                                                <small class="text-muted"><?php echo e($consignment->to_location); ?></small>
                                            </div>
                                        </td>
                                        <td>₹<?php echo e(number_format($consignment->total_amount, 2)); ?></td>
                                        <td>
                                            <?php switch($consignment->status):
                                                case ('pending'): ?>
                                                    <span class="badge bg-warning">Pending</span>
                                                    <?php break; ?>
                                                <?php case ('in_transit'): ?>
                                                    <span class="badge bg-info">In Transit</span>
                                                    <?php break; ?>
                                                <?php case ('delivered'): ?>
                                                    <span class="badge bg-success">Delivered</span>
                                                    <?php break; ?>
                                                <?php case ('cancelled'): ?>
                                                    <span class="badge bg-danger">Cancelled</span>
                                                    <?php break; ?>
                                                <?php default: ?>
                                                    <span class="badge bg-secondary">Unknown</span>
                                            <?php endswitch; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('admin.consignments.show', $consignment)); ?>" 
                                               class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <?php if($consignor->consignments->count() > 5): ?>
                        <div class="card-footer bg-white text-center">
                            <a href="<?php echo e(route('admin.consignments.index', ['consignor' => $consignor->id])); ?>" 
                               class="btn btn-outline-primary btn-sm">
                                View All Consignments
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\logistics\resources\views/admin/consignors/show.blade.php ENDPATH**/ ?>