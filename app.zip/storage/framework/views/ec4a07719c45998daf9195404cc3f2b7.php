

<?php $__env->startSection('title', 'Add New Truck'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col-md-6">
            <h1 class="h3 mb-0">Add New Truck</h1>
            <p class="text-muted">Register a new truck and driver information</p>
        </div>
        <div class="col-md-6 text-end">
            <a href="<?php echo e(route('admin.trucks.index')); ?>" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i>
                Back to Trucks
            </a>
        </div>
    </div>

    <!-- Form Card -->
    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-truck me-2"></i>
                        Truck Information
                    </h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('admin.trucks.store')); ?>">
                        <?php echo csrf_field(); ?>
                        
                        <div class="row">
                            <!-- Truck Number -->
                            <div class="col-md-6 mb-3">
                                <label for="truck_number" class="form-label">
                                    Truck Number <span class="text-danger">*</span>
                                </label>
                                <input type="text" 
                                       class="form-control <?php $__errorArgs = ['truck_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="truck_number" 
                                       name="truck_number" 
                                       value="<?php echo e(old('truck_number')); ?>" 
                                       placeholder="Enter truck number"
                                       required>
                                <?php $__errorArgs = ['truck_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Driver Name -->
                            <div class="col-md-6 mb-3">
                                <label for="driver_name" class="form-label">
                                    Driver Name <span class="text-danger">*</span>
                                </label>
                                <input type="text" 
                                       class="form-control <?php $__errorArgs = ['driver_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="driver_name" 
                                       name="driver_name" 
                                       value="<?php echo e(old('driver_name')); ?>" 
                                       placeholder="Enter driver name"
                                       required>
                                <?php $__errorArgs = ['driver_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Driver Phone -->
                            <div class="col-md-6 mb-3">
                                <label for="driver_phone" class="form-label">Driver Phone</label>
                                <input type="tel" 
                                       class="form-control <?php $__errorArgs = ['driver_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="driver_phone" 
                                       name="driver_phone" 
                                       value="<?php echo e(old('driver_phone')); ?>" 
                                       placeholder="Enter phone number">
                                <?php $__errorArgs = ['driver_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Driver License -->
                            <div class="col-md-6 mb-3">
                                <label for="driver_license" class="form-label">Driver License</label>
                                <input type="text" 
                                       class="form-control <?php $__errorArgs = ['driver_license'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="driver_license" 
                                       name="driver_license" 
                                       value="<?php echo e(old('driver_license')); ?>" 
                                       placeholder="Enter license number">
                                <?php $__errorArgs = ['driver_license'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Truck Type -->
                            <div class="col-md-6 mb-3">
                                <label for="truck_type" class="form-label">Truck Type</label>
                                <select class="form-select <?php $__errorArgs = ['truck_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                        id="truck_type" 
                                        name="truck_type">
                                    <option value="">Select truck type</option>
                                    <option value="flatbed" <?php echo e(old('truck_type') == 'flatbed' ? 'selected' : ''); ?>>Flatbed</option>
                                    <option value="box_truck" <?php echo e(old('truck_type') == 'box_truck' ? 'selected' : ''); ?>>Box Truck</option>
                                    <option value="refrigerated" <?php echo e(old('truck_type') == 'refrigerated' ? 'selected' : ''); ?>>Refrigerated</option>
                                    <option value="tanker" <?php echo e(old('truck_type') == 'tanker' ? 'selected' : ''); ?>>Tanker</option>
                                    <option value="dump_truck" <?php echo e(old('truck_type') == 'dump_truck' ? 'selected' : ''); ?>>Dump Truck</option>
                                    <option value="pickup" <?php echo e(old('truck_type') == 'pickup' ? 'selected' : ''); ?>>Pickup</option>
                                    <option value="trailer" <?php echo e(old('truck_type') == 'trailer' ? 'selected' : ''); ?>>Trailer</option>
                                </select>
                                <?php $__errorArgs = ['truck_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Capacity -->
                            <div class="col-md-6 mb-3">
                                <label for="capacity" class="form-label">Capacity (tons)</label>
                                <input type="number" 
                                       class="form-control <?php $__errorArgs = ['capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="capacity" 
                                       name="capacity" 
                                       value="<?php echo e(old('capacity')); ?>" 
                                       placeholder="Enter capacity in tons"
                                       step="0.01"
                                       min="0">
                                <?php $__errorArgs = ['capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Status -->
                            <div class="col-md-6 mb-3">
                                <label for="is_active" class="form-label">Status</label>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" 
                                           type="checkbox" 
                                           id="is_active" 
                                           name="is_active" 
                                           value="1" 
                                           <?php echo e(old('is_active', '1') ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="is_active">
                                        Active
                                    </label>
                                </div>
                                <?php $__errorArgs = ['is_active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Form Actions -->
                        <div class="row mt-4">
                            <div class="col-12">
                                <hr>
                                <div class="d-flex justify-content-end gap-2">
                                    <a href="<?php echo e(route('admin.trucks.index')); ?>" class="btn btn-outline-secondary">
                                        <i class="fas fa-times me-2"></i>
                                        Cancel
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>
                                        Save Truck
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Help Card -->
        <div class="col-lg-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-info-circle me-2"></i>
                        Help & Guidelines
                    </h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h6 class="fw-bold">Required Fields</h6>
                        <ul class="list-unstyled small text-muted">
                            <li><i class="fas fa-asterisk text-danger me-1"></i>Truck Number</li>
                            <li><i class="fas fa-asterisk text-danger me-1"></i>Driver Name</li>
                        </ul>
                    </div>
                    
                    <div class="mb-3">
                        <h6 class="fw-bold">Truck Types</h6>
                        <ul class="list-unstyled small text-muted">
                            <li><strong>Flatbed:</strong> Open cargo area</li>
                            <li><strong>Box Truck:</strong> Enclosed cargo area</li>
                            <li><strong>Refrigerated:</strong> Temperature controlled</li>
                            <li><strong>Tanker:</strong> Liquid transport</li>
                            <li><strong>Dump Truck:</strong> For bulk materials</li>
                        </ul>
                    </div>

                    <div class="mb-3">
                        <h6 class="fw-bold">Tips</h6>
                        <ul class="list-unstyled small text-muted">
                            <li>• Truck number should be unique</li>
                            <li>• Include driver contact for emergencies</li>
                            <li>• Set appropriate capacity for load planning</li>
                            <li>• Keep inactive trucks for historical records</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\logistics\resources\views/admin/trucks/create.blade.php ENDPATH**/ ?>