<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'subtitle',
        'head_office_address',
        'godown_address',
        'email',
        'mobile_numbers',
        'gstin',
        'msme_no',
        'eway_bill_id',
        'bank_name',
        'account_name',
        'account_number',
        'ifsc_code',
        'jurisdiction',
        'logo_path',
        'is_active',
    ];

    protected $casts = [
        'mobile_numbers' => 'array',
        'is_active' => 'boolean',
    ];

    public function consignments()
    {
        return $this->hasMany(Consignment::class);
    }
}
